package com.hostutil.resultsender;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Floating SEND button + WhatsApp automation.
 * Is app mein INTERNET permission nahi hai, isliye ye kuch bhi phone se bahar nahi bhej sakta.
 */
public class SenderService extends AccessibilityService {

    public static SenderService instance;

    private static final int GREEN = Color.parseColor("#2E7D32");
    private static final int GREY = Color.parseColor("#616161");
    private static final int ORANGE = Color.parseColor("#EF6C00");
    private static final int RED = Color.parseColor("#C62828");

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TextView btn;
    private WindowManager.LayoutParams params;

    private boolean active = false;
    private boolean sending = false;

    private String lastForegroundPkg;
    private String lastWaClass;
    private String waPkg = "com.whatsapp";
    private String returnPkg;
    private String group = "";

    private long sendStart;
    private long lastSendClick;
    private long lastSendSeen;
    private int sendClicks;
    private int ticksInWa;
    private boolean groupClicked;
    private boolean searchOpened;
    private boolean searchTyped;
    private long sentMaxAdded;
    private int sentCount;

    private static class Shot {
        long id;
        long added;
    }

    private interface Match {
        boolean ok(AccessibilityNodeInfo n);
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        active = false;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        active = false;
        sending = false;
        handler.removeCallbacksAndMessages(null);
        hideButton();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        handler.removeCallbacksAndMessages(null);
        hideButton();
        super.onDestroy();
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pk = e.getPackageName();
        if (pk == null) return;
        String p = pk.toString();
        if (p.equals("com.whatsapp") || p.equals("com.whatsapp.w4b")) {
            if (e.getClassName() != null) lastWaClass = e.getClassName().toString();
            return;
        }
        if (usable(p)) lastForegroundPkg = p;
    }

    // ------------------------------------------------------------------ on / off (tile)

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean on) {
        if (on == active) return;
        active = on;
        if (on) {
            // ON karne ke baad ke hi screenshots queue mein aayenge
            prefs().edit().putLong("since", System.currentTimeMillis() / 1000).apply();
            showButton();
            handler.post(refreshLoop);
        } else {
            handler.removeCallbacks(refreshLoop);
            hideButton();
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("prefs", MODE_PRIVATE);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ floating button

    private void showButton() {
        if (btn != null) return;
        btn = new TextView(this);
        btn.setGravity(Gravity.CENTER);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12);
        btn.setTypeface(null, Typeface.BOLD);
        int size = dp(64);
        btn.setWidth(size);
        btn.setHeight(size);
        btn.setText("SEND\n0");
        paint(GREY);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = prefs().getInt("bx", dp(16));
        params.y = prefs().getInt("by", dp(180));

        btn.setOnTouchListener(new DragListener());
        try {
            wm.addView(btn, params);
        } catch (Exception ex) {
            btn = null;
            active = false;
            toast("Button nahi aa paya: " + ex.getMessage());
        }
    }

    private void hideButton() {
        if (btn != null) {
            try {
                wm.removeView(btn);
            } catch (Exception ignored) {
            }
            btn = null;
        }
    }

    private void paint(int color) {
        if (btn == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(color);
        gd.setStroke(dp(2), Color.WHITE);
        btn.setBackground(gd);
        btn.setAlpha(0.92f);
    }

    private final Runnable refreshLoop = new Runnable() {
        @Override
        public void run() {
            if (!active) return;
            if (!sending) updateLabel();
            handler.postDelayed(this, 1500);
        }
    };

    private void updateLabel() {
        if (btn == null) return;
        try {
            int n = queryNew().size();
            btn.setText("SEND\n" + n);
            paint(n > 0 ? GREEN : GREY);
        } catch (SecurityException se) {
            btn.setText("PERM\n!");
            paint(RED);
        } catch (Exception ignored) {
        }
    }

    private void setBusyLabel() {
        if (btn == null) return;
        btn.setText("...\n" + sentCount);
        paint(ORANGE);
    }

    private void resetQueue() {
        if (sending) return;
        prefs().edit().putLong("since", System.currentTimeMillis() / 1000).apply();
        updateLabel();
        toast("Queue khali kar di");
    }

    private class DragListener implements View.OnTouchListener {
        private int startX;
        private int startY;
        private float touchX;
        private float touchY;
        private boolean moved;
        private boolean longFired;
        private final Runnable longPress = new Runnable() {
            @Override
            public void run() {
                if (!moved) {
                    longFired = true;
                    resetQueue();
                }
            }
        };

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = params.x;
                    startY = params.y;
                    touchX = e.getRawX();
                    touchY = e.getRawY();
                    moved = false;
                    longFired = false;
                    handler.postDelayed(longPress, 800);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - touchX;
                    float dy = e.getRawY() - touchY;
                    if (!moved && (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6))) {
                        moved = true;
                        handler.removeCallbacks(longPress);
                    }
                    if (moved && btn != null) {
                        params.x = startX + (int) dx;
                        params.y = startY + (int) dy;
                        try {
                            wm.updateViewLayout(btn, params);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    handler.removeCallbacks(longPress);
                    if (moved) {
                        prefs().edit().putInt("bx", params.x).putInt("by", params.y).apply();
                    } else if (!longFired) {
                        startSend();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(longPress);
                    return true;
                default:
                    return false;
            }
        }
    }

    // ------------------------------------------------------------------ screenshots queue

    private List<Shot> queryNew() {
        List<Shot> out = new ArrayList<>();
        long since = prefs().getLong("since", System.currentTimeMillis() / 1000);
        Uri base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] proj = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_ADDED};
        String sel = "(" + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ? OR "
                + MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?) AND "
                + MediaStore.MediaColumns.DATE_ADDED + " > ?";
        String[] args = {"%Screenshot%", "Screenshot%", String.valueOf(since)};
        String order = MediaStore.MediaColumns.DATE_ADDED + " ASC, " + MediaStore.MediaColumns._ID + " ASC";
        Cursor c = getContentResolver().query(base, proj, sel, args, order);
        if (c != null) {
            try {
                while (c.moveToNext()) {
                    Shot s = new Shot();
                    s.id = c.getLong(0);
                    s.added = c.getLong(1);
                    out.add(s);
                }
            } finally {
                c.close();
            }
        }
        // WhatsApp ek baar mein 30 tak leta hai: sabse naye 30 rakho
        while (out.size() > 30) out.remove(0);
        return out;
    }

    // ------------------------------------------------------------------ sending

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!sending) return;
            try {
                step();
            } catch (Exception ignored) {
            }
            if (sending) handler.postDelayed(this, 350);
        }
    };

    private void startSend() {
        if (sending) return;
        List<Shot> shots;
        try {
            shots = queryNew();
        } catch (Exception ex) {
            toast("Screenshot padh nahi paya. App kholke storage permission do.");
            return;
        }
        if (shots.isEmpty()) {
            toast("Koi naya screenshot nahi mila");
            return;
        }
        String wa = pickWhatsApp();
        if (wa == null) {
            toast("WhatsApp nahi mila");
            return;
        }
        waPkg = wa;
        group = prefs().getString("group", "").trim();
        returnPkg = detectForeground();

        ArrayList<Uri> uris = new ArrayList<>();
        long maxAdded = 0;
        for (Shot s : shots) {
            uris.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, s.id));
            maxAdded = Math.max(maxAdded, s.added);
        }
        sentMaxAdded = maxAdded;
        sentCount = uris.size();

        Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
        i.setType("image/*");
        i.setPackage(waPkg);
        i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        ClipData cd = ClipData.newRawUri("shots", uris.get(0));
        for (int k = 1; k < uris.size(); k++) {
            cd.addItem(new ClipData.Item(uris.get(k)));
        }
        i.setClipData(cd);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

        sendClicks = 0;
        ticksInWa = 0;
        groupClicked = false;
        searchOpened = false;
        searchTyped = false;
        lastWaClass = null;
        lastSendClick = 0;
        lastSendSeen = 0;
        sendStart = SystemClock.elapsedRealtime();

        try {
            startActivity(i);
        } catch (Exception ex) {
            toast("WhatsApp nahi khul paya");
            return;
        }
        sending = true;
        setBusyLabel();
        handler.postDelayed(tick, 700);
    }

    private String pickWhatsApp() {
        String[] cands = {"com.whatsapp", "com.whatsapp.w4b"};
        for (String p : cands) {
            try {
                getPackageManager().getPackageInfo(p, 0);
                return p;
            } catch (PackageManager.NameNotFoundException ignored) {
            }
        }
        return null;
    }

    private boolean usable(String p) {
        return p != null
                && !p.equals(getPackageName())
                && !p.equals("com.android.systemui")
                && !p.contains("inputmethod")
                && !p.contains("keyboard");
    }

    private String detectForeground() {
        try {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null && r.getPackageName() != null) {
                String p = r.getPackageName().toString();
                if (usable(p) && !p.startsWith("com.whatsapp")) return p;
            }
        } catch (Exception ignored) {
        }
        return lastForegroundPkg;
    }

    private void step() {
        long now = SystemClock.elapsedRealtime();
        long limit = group.isEmpty() ? 60000 : 35000;
        if (now - sendStart > limit) {
            finishSend(sendClicks > 0);
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        CharSequence rp = root.getPackageName();
        if (rp == null || !waPkg.equals(rp.toString())) return;
        ticksInWa++;

        AccessibilityNodeInfo send = findSendNode(root);
        if (send != null) {
            lastSendSeen = now;
            if (now - lastSendClick > 900 && click(send)) {
                sendClicks++;
                lastSendClick = now;
            }
            return;
        }

        if (!group.isEmpty() && !groupClicked) {
            chooseGroup(root);
            return;
        }

        boolean convo = lastWaClass != null && lastWaClass.contains("Conversation");
        if (sendClicks > 0 && now - lastSendClick > 1500 && (convo || now - lastSendSeen > 2500)) {
            finishSend(true);
        }
    }

    private void chooseGroup(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo g = findExact(root, group);
        if (g != null) {
            if (click(g)) groupClicked = true;
            return;
        }
        if (!searchOpened) {
            if (ticksInWa < 4) return; // pehle list load hone do
            AccessibilityNodeInfo s = firstVisible(
                    root.findAccessibilityNodeInfosByViewId(waPkg + ":id/menuitem_search"));
            if (s == null) {
                s = find(root, new Match() {
                    @Override
                    public boolean ok(AccessibilityNodeInfo n) {
                        return n.isVisibleToUser()
                                && str(n.getContentDescription()).toLowerCase().contains("search");
                    }
                });
            }
            if (s != null && click(s)) searchOpened = true;
            return;
        }
        if (!searchTyped) {
            AccessibilityNodeInfo et = find(root, new Match() {
                @Override
                public boolean ok(AccessibilityNodeInfo n) {
                    return isEdit(n) && n.isVisibleToUser();
                }
            });
            if (et != null) {
                et.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                Bundle b = new Bundle();
                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, group);
                if (et.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) searchTyped = true;
            }
        }
    }

    private void finishSend(boolean ok) {
        sending = false;
        handler.removeCallbacks(tick);
        if (ok) {
            prefs().edit().putLong("since", sentMaxAdded).apply();
        }
        final String msg;
        if (ok) {
            msg = sentCount + " screenshot bhej diye ✅";
        } else if (!group.isEmpty() && !groupClicked) {
            msg = "Send nahi hua: group \"" + group + "\" nahi mila. Naam check karo.";
        } else {
            msg = "Send nahi hua. WhatsApp check karo.";
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                goBackToGame();
                toast(msg);
                updateLabel();
            }
        }, ok ? 1500 : 300);
    }

    private void goBackToGame() {
        Intent li = null;
        PackageManager pm = getPackageManager();
        if (returnPkg != null) li = pm.getLaunchIntentForPackage(returnPkg);
        if (li == null) {
            String[] ff = {"com.dts.freefiremax", "com.dts.freefireth"};
            for (String p : ff) {
                li = pm.getLaunchIntentForPackage(p);
                if (li != null) break;
            }
        }
        if (li != null) {
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(li);
                return;
            } catch (Exception ignored) {
            }
        }
        performGlobalAction(GLOBAL_ACTION_BACK);
    }

    // ------------------------------------------------------------------ node helpers

    private AccessibilityNodeInfo findSendNode(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo byId = firstVisible(
                root.findAccessibilityNodeInfosByViewId(waPkg + ":id/send"));
        if (byId != null) return byId;
        return find(root, new Match() {
            @Override
            public boolean ok(AccessibilityNodeInfo n) {
                if (isEdit(n) || !n.isVisibleToUser() || !n.isEnabled()) return false;
                return isSendLabel(str(n.getContentDescription())) || isSendLabel(str(n.getText()));
            }
        });
    }

    private boolean isSendLabel(String s) {
        return s.equalsIgnoreCase("send") || s.equals("भेजें");
    }

    private AccessibilityNodeInfo findExact(AccessibilityNodeInfo root, String text) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(text);
        if (l == null) return null;
        for (AccessibilityNodeInfo n : l) {
            if (isEdit(n) || !n.isVisibleToUser()) continue;
            if (str(n.getText()).equalsIgnoreCase(text.trim())) return n;
        }
        return null;
    }

    private AccessibilityNodeInfo firstVisible(List<AccessibilityNodeInfo> l) {
        if (l == null) return null;
        for (AccessibilityNodeInfo n : l) {
            if (n.isVisibleToUser() && n.isEnabled()) return n;
        }
        return null;
    }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo n, Match m) {
        if (n == null) return null;
        if (m.ok(n)) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), m);
            if (r != null) return r;
        }
        return null;
    }

    private boolean click(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 6 && cur != null; i++) {
            if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            cur = cur.getParent();
        }
        return false;
    }

    private boolean isEdit(AccessibilityNodeInfo n) {
        CharSequence c = n.getClassName();
        return c != null && c.toString().contains("EditText");
    }

    private static String str(CharSequence c) {
        return c == null ? "" : c.toString().trim();
    }
}
