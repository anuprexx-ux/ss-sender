package com.hostutil.resultsender;

import android.content.Intent;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

/** Notification panel ka ON/OFF tile. ON = floating SEND button dikhega. */
public class ToggleTileService extends TileService {

    @Override
    public void onStartListening() {
        refresh();
    }

    @Override
    public void onClick() {
        SenderService s = SenderService.instance;
        if (s == null) {
            Toast.makeText(getApplicationContext(), "Pehle Accessibility ON karo", Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityAndCollapse(i);
            return;
        }
        s.setActive(!s.isActive());
        refresh();
    }

    private void refresh() {
        Tile t = getQsTile();
        if (t == null) return;
        SenderService s = SenderService.instance;
        boolean on = s != null && s.isActive();
        t.setLabel("Result Sender");
        t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.updateTile();
    }
}
