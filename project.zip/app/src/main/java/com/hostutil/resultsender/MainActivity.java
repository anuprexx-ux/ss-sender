package com.hostutil.resultsender;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView status;
    private EditText groupBox;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);

        int pad = dp(20);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Result Sender");
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, dp(12), 0, dp(12));
        root.addView(status);

        root.addView(button("1. Accessibility ON karo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));

        root.addView(button("2. Screenshot padhne ki permission do", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            }
        }));

        TextView groupLabel = new TextView(this);
        groupLabel.setText("3. WhatsApp group ka naam (bilkul wahi jo WhatsApp mein dikhta hai, emoji sahit). Khali chhodoge toh WhatsApp ki list khulegi aur tum khud group chunoge.");
        groupLabel.setPadding(0, dp(16), 0, dp(4));
        root.addView(groupLabel);

        groupBox = new EditText(this);
        groupBox.setSingleLine(true);
        groupBox.setHint("Group ka naam");
        groupBox.setText(prefs.getString("group", ""));
        root.addView(groupBox);

        root.addView(button("Naam save karo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().putString("group", groupBox.getText().toString().trim()).apply();
                Toast.makeText(MainActivity.this, "Save ho gaya", Toast.LENGTH_SHORT).show();
            }
        }));

        TextView help = new TextView(this);
        help.setPadding(0, dp(20), 0, 0);
        help.setText(
                "4. Notification panel neeche kheencho, edit (pencil) dabao, \"Result Sender\" tile ko upar kheench ke add karo.\n\n"
                + "Match result pe:\n"
                + "- Tile ON karo. Floating SEND button aayega.\n"
                + "- Apne screenshots lo (power + volume down). Button pe count dikhega.\n"
                + "- SEND dabao. WhatsApp 2-3 second ke liye khulega, sab bhejega, aur game wapas aa jayega.\n"
                + "- Button ko kheench ke kahin bhi rakh sakte ho.\n"
                + "- Button ko lamba dabao (long-press) = ab tak ke screenshots queue se hata do.\n"
                + "- Kaam khatam hone par tile OFF kar do.\n\n"
                + "Sirf tile ON karne ke BAAD ke screenshots hi jayenge. Is app mein internet permission nahi hai.");
        root.addView(help);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshStatus();
    }

    private void refreshStatus() {
        boolean acc = SenderService.instance != null;
        boolean storage = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
        status.setText(
                "Accessibility: " + (acc ? "ON ✅" : "OFF ❌  (Settings > Accessibility > Result Sender > ON)")
                + "\nScreenshot permission: " + (storage ? "mil gayi ✅" : "nahi mili ❌"));
    }
}
